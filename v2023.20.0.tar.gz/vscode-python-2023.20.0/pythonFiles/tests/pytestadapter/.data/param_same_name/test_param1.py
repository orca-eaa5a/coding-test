# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.
import pytest


@pytest.mark.parametrize("num", ["a", "b", "c"])
def test_odd_even(num):
    assert True
