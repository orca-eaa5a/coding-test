# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.


# This file has no tests in it; the discovery will return an empty list of tests.
def function_function(string):
    return string
