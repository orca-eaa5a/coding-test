

# ?!?
CHORUS = 'spamspamspamspamspam...'


def test_simple():
    assert True
