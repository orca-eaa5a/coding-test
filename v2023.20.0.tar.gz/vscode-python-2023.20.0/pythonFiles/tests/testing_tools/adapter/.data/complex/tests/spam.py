
def test_simple():
    assert True
