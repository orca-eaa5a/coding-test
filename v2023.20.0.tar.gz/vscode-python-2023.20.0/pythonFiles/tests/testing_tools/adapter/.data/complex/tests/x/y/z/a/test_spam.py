"""
...
"""


# ...

ANSWER = 42


def test_simple():
    assert True
